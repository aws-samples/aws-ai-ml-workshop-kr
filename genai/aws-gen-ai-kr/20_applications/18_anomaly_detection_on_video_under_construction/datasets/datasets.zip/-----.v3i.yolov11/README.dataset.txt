# 两点钟模型 > 2024-09-05 1:15am
https://universe.roboflow.com/liangdianzhong/-qvdww

Provided by a Roboflow user
License: CC BY 4.0

